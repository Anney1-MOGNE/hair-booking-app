document.getElementById("bookingForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const date = document.getElementById("date").value;
  const time = document.getElementById("time").value;
  const service = document.getElementById("service").value;

  const confirmation = document.getElementById("confirmation");
  confirmation.classList.remove("hidden");
  confirmation.innerHTML = `✅ Hi ${name}, your appointment for <strong>${service}</strong> is booked on <strong>${date}</strong> at <strong>${time}</strong>. Thank you!`;
});

document.getElementById("cancelBtn").addEventListener("click", function () {
  const name = document.getElementById("name").value;
  const date = document.getElementById("date").value;
  const time = document.getElementById("time").value;
  const service = document.getElementById("service").value;

  if (!date || !time || !name || !service) {
    alert("Please fill in the booking form before cancelling.");
    return;
  }

  const appointmentDateTime = new Date(`${date}T${time}`);
  const now = new Date();
  const diffInMs = appointmentDateTime - now;
  const diffInHours = diffInMs / (1000 * 60 * 60);

  let fee = 0;
  if (diffInHours >= 24) {
    fee = 0;
  } else if (diffInHours < 2) {
    fee = 800;
  } else {
    fee = 400;
  }

  const confirmCancel = confirm(`If you cancel now, you’ll be charged R${fee}. Do you want to continue?`);

  if (confirmCancel) {
    const cancellation = {
      name,
      date,
      time,
      service,
      fee,
      cancelledAt: new Date().toLocaleString(),
    };

    let cancellations = JSON.parse(localStorage.getItem("cancellations")) || [];
    cancellations.push(cancellation);
    localStorage.setItem("cancellations", JSON.stringify(cancellations));

    // WhatsApp integration (update number when ready)
    const message = `Hi Anec 👋, someone just cancelled their booking.\n\nName: ${name}\nService: ${service}\nDate: ${date}\nTime: ${time}\nCancellation Fee: R${fee}\nCancelled At: ${cancellation.cancelledAt}`;
    const phoneNumber = "27720000000"; // Replace with your real number later
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");

    alert("Appointment cancelled. Fee recorded.");
    document.getElementById("bookingForm").reset();
    displayCancellations();
  }
});

document.getElementById("clearCancellationsBtn").addEventListener("click", function () {
  const confirmClear = confirm("Are you sure you want to delete all cancellation records?");
  if (confirmClear) {
    localStorage.removeItem("cancellations");
    displayCancellations();
    alert("All cancellation history cleared.");
  }
});

function displayCancellations() {
  const list = document.getElementById("cancellationList");
  list.innerHTML = "";

  const cancellations = JSON.parse(localStorage.getItem("cancellations")) || [];
  cancellations.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = `${item.name} cancelled ${item.service} for ${item.date} at ${item.time} – Fee: R${item.fee} (on ${item.cancelledAt})`;
    list.appendChild(li);
  });
}

displayCancellations();
